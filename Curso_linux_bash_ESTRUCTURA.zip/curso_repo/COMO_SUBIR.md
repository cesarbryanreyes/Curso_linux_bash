# Cómo subir estos archivos a tu repo del curso

> Estos archivos extienden tu repositorio `Curso_linux_bash` para convertirlo en el repo del **curso** (no solo del webinar). No borran el Release `v1.0/sub.tar`.

## Opción A — Por la web (más simple)
1. Entra a tu repo en github.com/cesarbryanreyes/Curso_linux_bash
2. **Add file → Upload files** y arrastra estas carpetas/archivos.
3. Escribe un mensaje de commit (ej. "Estructura del curso: datos M0 y M1") y confirma.

## Opción B — Por terminal (git)
```bash
# Dentro de una copia local de tu repo
git clone https://github.com/cesarbryanreyes/Curso_linux_bash.git
cd Curso_linux_bash

# Copia aquí el contenido de esta carpeta (README.md, datos/, M0_preparacion/, etc.)
# Recomendado: mueve el README del webinar a webinar/ para no perderlo:
#   mkdir -p webinar && git mv README.md webinar/README.md   (antes de copiar el nuevo README.md)

git add .
git commit -m "Estructura del curso CEM-BIO-101: guías de descarga M0 y M1"
git push origin main
```

## Nota
- El nuevo `README.md` es el **portal del curso**. Si quieres conservar el README del webinar, muévelo a `webinar/README.md` (ver arriba).
- La carpeta `data/` está en `.gitignore`: los datos NO se versionan, se descargan con las guías o con `scripts/descargar_datos.sh`.
